import avatar from './assets/a.png';
import './style.less'
function Content() {
    const container = document.getElementById('root');
    container.innerText = 'content';
    const img = document.createElement('img');
    img.src = avatar;
    img.classList.add('avatar');
    console.log(avatar);
    container.appendChild(img);
}

export default Content;