import Content from './content.js';
import Img from './assets/a.png';
new Content();
